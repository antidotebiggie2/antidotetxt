'use client';
import { useState, useEffect } from 'react';
import io from 'socket.io-client';
const socket = io(process.env.NEXT_PUBLIC_BACKEND_URL!);

export default function ChatPage() {
  const [msg, setMsg] = useState('');
  const [chat, setChat] = useState<string[]>([]);

  useEffect(() => {
    socket.on('receive-message', m => setChat(c => [...c, m]));
  }, []);

  const send = () => {
    if (msg.trim()) {
      socket.emit('send-message', msg);
      setMsg('');
    }
  };

  return (
    <div>
      <div className="chat-window">
        {chat.map((m, i) => <p key={i} dangerouslySetInnerHTML={{ __html: m }}></p>)}
      </div>
      <input
        value={msg}
        onChange={e => setMsg(e.target.value)}
        placeholder="Type a message..."
      />
      <button onClick={send}>Send</button>
      <br/><br/>
      <VideoUploader socket={socket} />
    </div>
  );
}

function VideoUploader({ socket }: any) {
  const [videoUrl, setVideoUrl] = useState('');

  const upload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const fd = new FormData();
    fd.append('file', e.target.files[0]);
    const res = await fetch('/api/upload', { method: 'POST', body: fd });
    const body = await res.json();
    const url = body.file;
    socket.emit('send-message', `<video src="\${url}" controls width="300"></video>`);
  };

  return <input type="file" accept="video/*" onChange={upload} />;
}
