import { NextResponse } from 'next/server';
import formidable from 'formidable';
import fs from 'fs';

export const config = { api: { bodyParser: false } };

export async function POST(req: Request) {
  const form = formidable({ uploadDir: './public/uploads', keepExtensions: true });
  const data = await new Promise<any>((res, rej) => {
    form.parse(req, (err, fields, files) => {
      if (err) return rej(err);
      res(files.file);
    });
  });
  const filename = (data as any).filepath.split('/').pop();
  return NextResponse.json({ file: `/uploads/\${filename}` });
}
